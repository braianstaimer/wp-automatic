<?php

//wp-load
require_once('../../../wp-load.php');

require_once( dirname(__FILE__) . '/cron.php' );